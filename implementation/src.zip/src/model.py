
import torch
import pyro
import pyro.distributions as dist
from src.geometry import compute_distance_matrix
from src.penalty import get_fixed_quartets, soft_four_point_penalty

class PhylogeneticPrior:
    def __init__(self, N, K, B, seed=42):
        self.N = N
        self.K = K
        self.B = B
        self.fixed_indices = get_fixed_quartets(N, B, seed)

    def initialize(self, lmbda_4=1.0, lmbda_g=0.0, sigma_u=1.0, tau=0.1, use_scale=False, g0=0.1):
        """
        Generates the fully normalized prior landscape.
        """
        # 1. Coordinate Base Prior
        u = pyro.sample("u", dist.Normal(0, sigma_u).expand([self.N, self.K]).to_event(1))

        # 2. Hyperbolic Radial Projection
        u_norm = torch.norm(u, p=2, dim=-1, keepdim=True)
        u_norm_stable = torch.clamp(u_norm, min=1e-7)
        x = (u / u_norm_stable) * torch.tanh(u_norm)

        # 3. Pairwise Metric Construction
        D_raw = compute_distance_matrix(x)

        # 4. Scale Normalization
        triu_indices = torch.triu_indices(self.N, self.N, offset=1) # takes two arguments -row and column, 
        #offset=1 excluded diagnol.   #N,N matrix
        mean_D = torch.clamp(D_raw[triu_indices[0], triu_indices[1]].mean(), min=1e-6)
        #takes row indices and col indices, extracts those from D_raw matrix, takes the mean and ensures it is not too small
        D_tilde = D_raw / mean_D #takes upper triangle of distance matrix, calculated average distance, divides the entire matrix by this average



        # Expose relative patristic geometry to Pyro trace
        pyro.deterministic("D_tilde", D_tilde)

        # 5. Structural Penalization Forces
        # Term 1: Four-Point Penalty (P_4pt)
        if lmbda_4 != 0.0:
            p_4pt = soft_four_point_penalty(D_tilde, self.fixed_indices, tau).mean()
            pyro.factor("four_point_force", -lmbda_4 * p_4pt)
            
        # Term 2: Optional Gap Penalty to prevent star-like failure mode (P_gap)
        if lmbda_g != 0.0:
            a, b, c, d = self.fixed_indices[:, 0], self.fixed_indices[:, 1], self.fixed_indices[:, 2], self.fixed_indices[:, 3]
            s1 = D_tilde[a, b] + D_tilde[c, d]
            s2 = D_tilde[a, c] + D_tilde[b, d]
            s3 = D_tilde[a, d] + D_tilde[b, c]
            
            s_stacked = torch.stack([s1, s2, s3], dim=-1)
            s_sorted, _ = torch.sort(s_stacked, dim=-1)
            g_q = s_sorted[..., 1] - s_sorted[..., 0] # s_(2) - s_(1)
            
            p_gap = (g_q.mean() - g0) ** 2
            pyro.factor("gap_force", -lmbda_g * p_gap) #takes average quartet gap across training quartets, checks the deviation from minimum branch length
            #penalizes the square of this difference, via pyro.factor

        # 6. Optional Absolute Scale Reconstruction
        if use_scale:
            log_s = pyro.sample("log_s", dist.Normal(0.0, 1.0)) #s decides how much we want to shrink or expand our tree, because D tilde is always 1, but might not be in real world
            s = torch.exp(log_s) #ensures that s is positive
            D = pyro.deterministic("D", s * D_tilde)
            return D
            
        return D_tilde
    


